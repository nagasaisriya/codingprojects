/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.io.*;
public class Main
{
	public static void main(String[] args) {
	try{
	    int arr[]= new int[10];
	    int n;
		DataInputStream obj = new DataInputStream(System.in); 
		System.out.println("Enter size of array");
		n=Integer.parseInt(obj.readLine());
		System.out.println("Enter elements of array");
		for(int i=0;i<n;i++)
		{
		    arr[i]=Integer.parseInt(obj.readLine());
		}
		for(int i=0;i<n;i++)
		{
		    System.out.println(arr[i]);
		}
		int min=arr[0],max=arr[0],diff;
		for(int i=0;i<n;i++)
		{
		    if(arr[i]>max){
		        max=arr[i];
		    }
		}
		for(int i=0;i<n;i++)
		{
		    if(arr[i]<min)
		    {
		        min=arr[i];
		    }
		}
	
		System.out.println("Difference between maximum and minimum elements in array="+Math.abs(max-min));
	}catch(Exception e){
	    System.out.println("Exception found");
	}
	}
}
