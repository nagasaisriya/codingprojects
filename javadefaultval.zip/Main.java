/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
        static byte b;
	    static int i;
	    static short s;
	    static long l;
	    static double d;
	    static char c;
	    static float f;
	    static boolean v;
	public static void main(String[] args) 
	{
	    System.out.println("Default values of primitive datatypes are:"); 
	    System.out.println("byte="+b+"  short="+s+"  int="+i+"  long="+l+"  float="+f+"  double="+d+"  char="+c+"  boolean="+v);
//	Write a Java program to print the default values of primitive types. 

	}
}
