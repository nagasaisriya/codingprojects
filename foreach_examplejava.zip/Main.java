/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.io.*;
public class Main
{
	public static void main(String[] args) {
	//	System.out.println("Hello World");
   try{
       int arr[] = new int[5];
       System.out.println("Enter array elements:");
       DataInputStream obj=new DataInputStream(System.in);
       for(int i=0;i<5;i++)
       {
           arr[i]=Integer.parseInt(obj.readLine());
       }
       int sum = 0;
    
       // for each loop 
       for (int item: arr) {
         sum += item;
       }
      
       System.out.println("Sum of elements of array using for-each loop= " + sum);
	}catch(Exception e)
	{
	    System.out.println("Exception found");
	}
	}
}
