/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void read();
void add();
void sub();
void multi();
int a[10][10],b[10][10],i,j,k,r1,c1,r2,c2;
void read()
{
    printf("Enter order of A:");
    scanf("%d%d",&r1,&c1);
    printf("Enter order of B:");
    scanf("%d%d",&r2,&c2);
}
void readMatrix(){
    printf("Enter Matrix A-\n");
    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    printf("Enter Matrix B-\n");
    for(i=0;i<r2;i++)
    {
        for(j=0;j<c2;j++)
        {
            scanf("%d",&b[i][j]);
        }
    }
}
void add()
{
    int sum[10][10];
    read();
    if(r1==r2 && c1==c2)
    {
        readMatrix();
        for(i=0;i<r1;i++)
        {
            for(j=0;j<c1;j++)
            {
                sum[i][j]=a[i][j]+b[i][j];
            }
        }
        sum[i][j]=0;
        printf("ADDITION-\n");
        for(i=0;i<r1;i++)
        {
            for(j=0;j<c1;j++)
            {
                printf("%d ",sum[i][j]);
            }
            printf("\n");
        }
    }
    else
    {
        printf("Matrix ADDITION not possible\n");
        add();
    }
}
void sub()
{
    int dif[10][10];
    read();
    if(r1==r2 && c1==c2){
        readMatrix();
        for(i=0;i<r1;i++)
        {
            for(j=0;j<c1;j++)
            {
                dif[i][j]=a[i][j]-b[i][j];
            }
        }
        dif[i][j]=0;
        printf("SUBTRACTION-\n");
        for(i=0;i<r1;i++)
        {
            for(j=0;j<c1;j++)
            {
                printf("%d ",dif[i][j]);
            }
            printf("\n");
        }
    }
    else{
        printf("Matrix SUBTRACTION not possible\n");
        sub();
    }
}
void multi()
{
    int sum=0,mul[10][10];
    read();
    if(c1==r2)
    {
        readMatrix();
        for(i=0;i<r1;i++)
        {
            for(j=0;j<c2;j++)
            {
                for(k=0;k<r2;k++)
                {
                    sum+=a[i][k]*b[k][j];
                }
                mul[i][j]=sum;
                sum=0;
            }
        }
        printf("Matrix MULTIPLICATION-\n");
        for(i=0;i<r1;i++)
        {
            for(j=0;j<c2;j++)
            {
                printf("%3d ",mul[i][j]);
            }
            printf("\n");
        }
    }
    else
    {
        printf("Matrix mul not possible\n");
        multi();
    }
}

int main()
{
    int op;
    do{
        printf("Enter your option-\nChoose:\n1.ADDITION OF MATRICES\n2.SUBTRACTION OF MATRICES\n3.MULTIPLICATION OF MATRICES\n");
        scanf("%d",&op);
        switch(op)
        {
            case 1:add();break;
            case 2:sub();break;
            case 3:multi();break;
            default:printf("Invalid choice\n");
        }
    }while(op!=4);
    return 0;
}
