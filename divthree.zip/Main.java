/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		//System.out.println("Hello World");
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		for(int j=0;j<t;j++)
		{
		    int n=sc.nextInt();
		    long k=sc.nextInt();
		    long d=sc.nextInt();
		    long h=0;
		    for(int i=0;i<n;i++)
		    {
		        h+=sc.nextInt();
		    }
		    h=h/k;
		    if(h>d)
		    {
		        System.out.println(d);
		    }
		    else{
		        System.out.println(h);
		    } 
		}
		
	}
}
